import SwiftUI

@main
struct CustomAudiobookReaderApp: App {
    var body: some Scene {
        WindowGroup {
            PlayerDashboardView()
        }
    }
}