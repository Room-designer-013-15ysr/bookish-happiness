import SwiftUI
import AVFoundation
import UniformTypeIdentifiers

struct PlayerDashboardView: View {
    
    // MARK: - Engine & State
    @State private var engine = AudioPlayerEngine()
    
    @State private var bookTitle: String = "No Book Loaded"
    @State private var bookAuthor: String = "Import an .epub to begin"
    @State private var chapters: [ChapterSummary] = []
    
    // State to trigger the native file system picker sheet
    @State private var isShowingFileImporter = false
    
    private let backgroundGradient = LinearGradient(
        colors: [Color.black, Color(red: 0.08, green: 0.08, blue: 0.1)],
        startPoint: .top,
        endPoint: .bottom
    )
    
    var body: some View {
        NavigationStack {
            ZStack {
                backgroundGradient.ignoresSafeArea()
                
                VStack(spacing: 32) {
                    coverArt
                    bookInfo
                    chapterMenu
                    transportControls
                    speedControl
                    voicePicker
                    Spacer()
                }
                .padding(.horizontal, 24)
                .padding(.top, 24)
            }
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    // Triggers the file selection overlay sheet natively
                    Button {
                        isShowingFileImporter = true
                    } label: {
                        Label("Import", systemImage: "folder.badge.plus")
                    }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        // TODO(Step 3): VisionKit cover scanner camera routine placeholder
                    } label: {
                        Label("Scan Cover", systemImage: "camera.viewfinder")
                    }
                }
            }
            .navigationTitle("Now Reading")
            .navigationBarTitleDisplayMode(.inline)
            
            // MARK: - Native File Importer Mounting Context
            .fileImporter(
                isPresented: $isShowingFileImporter,
                allowedContentTypes: [UTType(filenameExtension: "epub")].compactMap { $0 },
                allowsMultipleSelection: false
            ) { result in
                switch result {
                case .success(let urls):
                    guard let selectedURL = urls.first else { return }
                    loadAndParseSideloadedBook(from: selectedURL)
                case .failure(let error):
                    print("System file picker failed: \(error.localizedDescription)")
                }
            }
        }
        .preferredColorScheme(.dark)
    }
    
    // MARK: - Core Execution Routine
    
    private func loadAndParseSideloadedBook(from url: URL) {
        // iOS requires security scoping clearance tokens to read raw data outside app boundaries
        guard url.startAccessingSecurityScopedResource() else {
            print("Access Denied to Security Sandbox Environment.")
            return
        }
        
        defer { url.stopAccessingSecurityScopedResource() }
        
        // Pass the verified local URL straight into our custom native engine
        if let parsedBook = EPUBManager.shared.parseEPUB(at: url) {
            self.bookTitle = parsedBook.title
            self.bookAuthor = parsedBook.author
            
            // Map structural chapter layers down into lightweight rendering summaries
            self.chapters = parsedBook.chapters.map { chapter in
                ChapterSummary(id: chapter.id, title: chapter.title)
            }
            
            // Pass total string structural models directly down into core playback engines
            engine.loadBookDataModel(parsedBook)
        }
    }
    
    // MARK: - UI Component Blocks
    
    private var coverArt: some View {
        RoundedRectangle(cornerRadius: 20)
            .fill(Color.white.opacity(0.06))
            .frame(width: 220, height: 220)
            .overlay(
                Image(systemName: "book.closed.fill")
                    .font(.system(size: 56))
                    .foregroundStyle(.white.opacity(0.35))
            )
            .shadow(color: .black.opacity(0.4), radius: 16, y: 8)
    }
    
    private var bookInfo: some View {
        VStack(spacing: 4) {
            Text(bookTitle)
                .font(.title2.weight(.semibold))
                .foregroundStyle(.white)
                .multilineTextAlignment(.center)
                .lineLimit(2)
            Text(bookAuthor)
                .font(.subheadline)
                .foregroundStyle(.white.opacity(0.5))
        }
    }
    
    private var chapterMenu: some View {
        Menu {
            if chapters.isEmpty {
                Text("No chapters yet")
            } else {
                ForEach(chapters) { chapter in
                    Button {
                        engine.jumpToChapter(chapter.id)
                    } label: {
                        if chapter.id == engine.currentChapterIndex {
                            Label(chapter.title, systemImage: "checkmark")
                        } else {
                            Text(chapter.title)
                        }
                    }
                }
            }
        } label: {
            dashboardRow(
                systemImage: "list.bullet",
                text: currentChapterTitle
            )
        }
    }
    
    private var currentChapterTitle: String {
        chapters.first(where: { $0.id == engine.currentChapterIndex })?.title ?? "Chapters"
    }
    
    private var transportControls: some View {
        HStack(spacing: 40) {
            Button {
                engine.skipToPreviousParagraph()
            } label: {
                Image(systemName: "backward.end.fill")
                    .font(.title2)
            }
            .accessibilityLabel("Previous paragraph")
            
            Button {
                engine.isPlaying ? engine.pause() : engine.play()
            } label: {
                Image(systemName: engine.isPlaying ? "pause.circle.fill" : "play.circle.fill")
                    .font(.system(size: 76))
                    .symbolRenderingMode(.hierarchical)
            }
            .accessibilityLabel(engine.isPlaying ? "Pause" : "Play")
            
            Button {
                engine.skipToNextParagraph()
            } label: {
                Image(systemName: "forward.end.fill")
                    .font(.title2)
            }
            .accessibilityLabel("Next paragraph")
        }
        .foregroundStyle(.white)
    }
    
    private var speedControl: some View {
        VStack(spacing: 8) {
            HStack {
                Text("Playback Speed")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.5))
                Spacer()
                Text(String(format: "%.1fx", engine.speedMultiplier))
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.white.opacity(0.85))
            }
            Slider(
                value: Binding(
                    get: { engine.speedMultiplier },
                    set: { engine.speedMultiplier = $0 }
                ),
                in: engine.minSpeedMultiplier...engine.maxSpeedMultiplier,
                step: 0.1
            )
            .tint(.white)
        }
    }
    
    private var voicePicker: some View {
        Menu {
            ForEach(engine.availableVoices, id: \.identifier) { voice in
                Button {
                    engine.selectVoice(voice)
                } label: {
                    if voice.identifier == engine.selectedVoiceIdentifier {
                        Label("\(voice.name) — \(voice.language)", systemImage: "checkmark")
                    } else {
                        Text("\(voice.name) — \(voice.language)")
                    }
                }
            }
        } label: {
            dashboardRow(
                systemImage: "person.wave.2",
                text: "Narrator: \(selectedVoiceName)"
            )
        }
    }
    
    private var selectedVoiceName: String {
        engine.availableVoices.first(where: { $0.identifier == engine.selectedVoiceIdentifier })?.name ?? "Default"
    }
    
    private func dashboardRow(systemImage: String, text: String) -> some View {
        HStack {
            Image(systemName: systemImage)
            Text(text)
                .lineLimit(1)
            Spacer()
            Image(systemName: "chevron.up.chevron.down")
                .font(.caption)
        }
        .foregroundStyle(.white.opacity(0.85))
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 14))
    }
}