import Foundation
import AVFoundation
import Observation

/// Represents a single paragraph of book text queued for narration.
/// EPUBManager (Step 2) will produce arrays of these from parsed chapter HTML/XHTML.
struct NarrationParagraph: Identifiable, Equatable {
    let id: Int
    let chapterIndex: Int
    let text: String
}

/// The core, 100%-offline text-to-speech playback engine.
/// Wraps AVSpeechSynthesizer and exposes a clean, SwiftUI-friendly API.
@Observable
final class AudioPlayerEngine: NSObject {

    // MARK: - Published Playback State

    private(set) var isPlaying: Bool = false
    private(set) var isPaused: Bool = false

    /// User-facing speed multiplier, shown in the UI as e.g. "1.5x". Range: 0.5x ... 3.0x.
    var speedMultiplier: Double = 1.0 {
        didSet {
            let clamped = min(max(speedMultiplier, minSpeedMultiplier), maxSpeedMultiplier)
            if clamped != speedMultiplier {
                speedMultiplier = clamped
                return
            }
            // If we're actively speaking, re-speak the current paragraph so the
            // new rate takes effect immediately instead of on the next paragraph.
            if isPlaying { speakCurrentParagraph() }
        }
    }

    /// Identifier of the currently selected narrator voice.
    private(set) var selectedVoiceIdentifier: String? {
        didSet {
            guard let identifier = selectedVoiceIdentifier else { return }
            UserDefaults.standard.set(identifier, forKey: Keys.selectedVoice)
        }
    }

    /// All narrator voices installed on-device (fully offline-capable, no network calls).
    private(set) var availableVoices: [AVSpeechSynthesisVoice] = []

    /// The flattened paragraph queue for the currently loaded book/chapter set.
    private(set) var paragraphs: [NarrationParagraph] = []

    /// Index into `paragraphs` for what is currently being (or about to be) spoken.
    /// Persisted automatically so the user never loses their spot.
    private(set) var currentParagraphIndex: Int = 0 {
        didSet { persistProgress() }
    }

    /// Index of the current chapter — kept in sync with `currentParagraphIndex`,
    /// used to drive Chapter Menu highlighting.
    private(set) var currentChapterIndex: Int = 0 {
        didSet { persistProgress() }
    }

    // MARK: - Public Constants

    let minSpeedMultiplier: Double = 0.5
    let maxSpeedMultiplier: Double = 3.0

    // MARK: - Persistence Keys

    private enum Keys {
        static let selectedVoice = "AudioPlayerEngine.selectedVoiceIdentifier"
        static let chapterIndex = "AudioPlayerEngine.currentChapterIndex"
        static let paragraphIndex = "AudioPlayerEngine.currentParagraphIndex"
    }

    // MARK: - AVFoundation

    private let synthesizer = AVSpeechSynthesizer()

    // MARK: - Init

    override init() {
        super.init()
        synthesizer.delegate = self
        configureAudioSession()
        loadAvailableVoices()
        restorePersistedProgress()
    }

    // MARK: - Audio Session

    private func configureAudioSession() {
        do {
            let session = AVAudioSession.sharedInstance()
            // .spokenAudio tells the system this is long-form narration (like a podcast),
            // which gets the right ducking/interruption behavior and, combined with the
            // "Audio, AirPlay, and Picture in Picture" background mode in Info.plist,
            // allows narration to continue with the screen locked.
            try session.setCategory(.playback, mode: .spokenAudio, options: [.duckOthers])
            try session.setActive(true)
        } catch {
            print("⚠️ AudioPlayerEngine: failed to configure audio session: \(error)")
        }
    }

    // MARK: - Voices

    private func loadAvailableVoices() {
        availableVoices = AVSpeechSynthesisVoice.speechVoices()
            .sorted { $0.name < $1.name }

        if let savedIdentifier = UserDefaults.standard.string(forKey: Keys.selectedVoice),
           availableVoices.contains(where: { $0.identifier == savedIdentifier }) {
            selectedVoiceIdentifier = savedIdentifier
        } else {
            selectedVoiceIdentifier = AVSpeechSynthesisVoice(
                language: AVSpeechSynthesisVoice.currentLanguageCode()
            )?.identifier
        }
    }

    func selectVoice(_ voice: AVSpeechSynthesisVoice) {
        selectedVoiceIdentifier = voice.identifier
        if isPlaying { speakCurrentParagraph() }
    }

    // MARK: - Loading Content
    // Step 2 (EPUBManager) will call this after parsing a book's TOC + chapter bodies
    // into a flat paragraph queue, optionally resuming at a saved index.

    func loadParagraphs(_ newParagraphs: [NarrationParagraph], startingAt paragraphIndex: Int = 0) {
        stop()
        paragraphs = newParagraphs
        let safeIndex = min(max(paragraphIndex, 0), max(newParagraphs.count - 1, 0))
        currentParagraphIndex = safeIndex
        currentChapterIndex = newParagraphs[safe: safeIndex]?.chapterIndex ?? 0
    }

    // MARK: - Transport Controls

    func play() {
        guard !paragraphs.isEmpty else { return }

        if isPaused {
            synthesizer.continueSpeaking()
            isPaused = false
            isPlaying = true
            return
        }

        speakCurrentParagraph()
    }

    func pause() {
        guard isPlaying else { return }
        synthesizer.pauseSpeaking(at: .word)
        isPlaying = false
        isPaused = true
    }

    func stop() {
        synthesizer.stopSpeaking(at: .immediate)
        isPlaying = false
        isPaused = false
    }

    /// Micro-navigation: jumps one paragraph forward, e.g. to re-hear a missed line.
    func skipToNextParagraph() {
        guard currentParagraphIndex + 1 < paragraphs.count else { return }
        currentParagraphIndex += 1
        currentChapterIndex = paragraphs[currentParagraphIndex].chapterIndex
        if isPlaying { speakCurrentParagraph() }
    }

    /// Micro-navigation: jumps one paragraph back.
    func skipToPreviousParagraph() {
        guard currentParagraphIndex - 1 >= 0 else { return }
        currentParagraphIndex -= 1
        currentChapterIndex = paragraphs[currentParagraphIndex].chapterIndex
        if isPlaying { speakCurrentParagraph() }
    }

    /// Jumps to the first paragraph of a given chapter — used by the Chapter Menu.
    func jumpToChapter(_ chapterIndex: Int) {
        guard let targetIndex = paragraphs.firstIndex(where: { $0.chapterIndex == chapterIndex }) else { return }
        currentChapterIndex = chapterIndex
        currentParagraphIndex = targetIndex
        if isPlaying || isPaused {
            speakCurrentParagraph()
        }
    }

    // MARK: - Speech Rate Mapping
    //
    // AVSpeechUtterance.rate is a *synthesis* parameter, not an audio time-stretch —
    // so unlike speeding up recorded audio, pitch never needs correction here.
    // We keep utterance.pitchMultiplier fixed at 1.0 and only ever touch `rate`.
    //
    // Apple's raw rate scale is AVSpeechUtteranceMinimumSpeechRate (0.0) through
    // AVSpeechUtteranceMaximumSpeechRate (1.0), with AVSpeechUtteranceDefaultSpeechRate
    // (0.5) sounding like natural conversational speech. That scale isn't a friendly
    // "0.5x–3.0x" multiplier for users, so we remap it piecewise, anchoring our "1.0x"
    // to Apple's natural default:
    //   0.5x ... 1.0x  →  minEngineRate ... defaultEngineRate
    //   1.0x ... 3.0x  →  defaultEngineRate ... maxEngineRate
    private func mappedEngineRate(for multiplier: Double) -> Float {
        let minEngine = AVSpeechUtteranceMinimumSpeechRate
        let maxEngine = AVSpeechUtteranceMaximumSpeechRate
        let defaultEngine = AVSpeechUtteranceDefaultSpeechRate

        if multiplier <= 1.0 {
            let t = Float((multiplier - minSpeedMultiplier) / (1.0 - minSpeedMultiplier))
            return minEngine + t * (defaultEngine - minEngine)
        } else {
            let t = Float((multiplier - 1.0) / (maxSpeedMultiplier - 1.0))
            return defaultEngine + t * (maxEngine - defaultEngine)
        }
    }

    // MARK: - Speaking

    private func speakCurrentParagraph() {
        guard let paragraph = paragraphs[safe: currentParagraphIndex] else { return }

        synthesizer.stopSpeaking(at: .immediate)

        let utterance = AVSpeechUtterance(string: paragraph.text)
        utterance.rate = mappedEngineRate(for: speedMultiplier)
        utterance.pitchMultiplier = 1.0 // Keep pitch natural at every speed.

        if let identifier = selectedVoiceIdentifier,
           let voice = AVSpeechSynthesisVoice(identifier: identifier) {
            utterance.voice = voice
        }

        synthesizer.speak(utterance)
        isPlaying = true
        isPaused = false
    }

    // MARK: - Progress Persistence

    private func persistProgress() {
        UserDefaults.standard.set(currentChapterIndex, forKey: Keys.chapterIndex)
        UserDefaults.standard.set(currentParagraphIndex, forKey: Keys.paragraphIndex)
    }

    private func restorePersistedProgress() {
        currentChapterIndex = UserDefaults.standard.integer(forKey: Keys.chapterIndex)
        currentParagraphIndex = UserDefaults.standard.integer(forKey: Keys.paragraphIndex)
    }
}

// MARK: - AVSpeechSynthesizerDelegate

extension AudioPlayerEngine: AVSpeechSynthesizerDelegate {
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        // Auto-advance to the next paragraph, the way a real narrator keeps reading.
        guard isPlaying else { return }
        if currentParagraphIndex + 1 < paragraphs.count {
            currentParagraphIndex += 1
            currentChapterIndex = paragraphs[currentParagraphIndex].chapterIndex
            speakCurrentParagraph()
        } else {
            isPlaying = false
        }
    }
}

// MARK: - Safe Array Subscript Helper

private extension Array {
    subscript(safe index: Int) -> Element? {
        indices.contains(index) ? self[index] : nil
    }
}
