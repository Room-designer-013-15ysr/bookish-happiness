import Foundation

/// Represents a completely parsed book ready for narration.
struct Book: Identifiable, Codable {
    let id: String // Usually the ISBN or a UUID generated from the filename
    let title: String
    let author: String
    let chapters: [Chapter]
}

/// Represents an individual chapter containing its readable blocks.
struct Chapter: Identifiable, Codable, Hashable {
    let id: Int
    let title: String
    let paragraphs: [String] // Broken down into individual strings for perfect tracking
}