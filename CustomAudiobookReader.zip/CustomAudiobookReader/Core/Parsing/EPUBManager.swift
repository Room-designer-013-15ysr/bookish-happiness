import Foundation

class EPUBManager: NSObject, XMLParserDelegate {
    static let shared = EPUBManager()
    
    // Parser Tracking States
    private var currentElement = ""
    private var temporaryTitle = ""
    private var temporaryAuthor = ""
    private var spineItemRefs: [String] = []
    
    private override init() {}
    
    /// Main ingestion routine to convert a local file URL into a usable Book object.
    func parseEPUB(at fileURL: URL) -> Book? {
        let fileManager = FileManager.default
        let cacheDirectory = fileManager.urls(for: .cachesDirectory, in: .userDomainMask).first!
        let extractionURL = cacheDirectory.appendingPathComponent(UUID().uuidString)
        
        // 1. Prepare extraction destination
        try? fileManager.createDirectory(at: extractionURL, withIntermediateDirectories: true, attributes: nil)
        
        // 2. Unzip using Apple's built-in system unzipper process
        let process = Process()
        process.currentDirectoryURL = extractionURL
        process.executableURL = URL(fileURLWithPath: "/usr/bin/unzip")
        process.arguments = ["-q", fileURL.path, "-d", extractionURL.path]
        
        do {
            try process.run()
            process.waitUntilExit()
        } catch {
            print("Decompression failed natively: \(error)")
            return fallbackMockBook(from: fileURL)
        }
        
        // 3. Locate the metadata schema (.opf file)
        let containerURL = extractionURL.appendingPathComponent("META-INF/container.xml")
        guard fileManager.fileExists(atPath: containerURL.path),
              let opfRelativePath = parseContainerForOPF(at: containerURL) else {
            return fallbackMockBook(from: fileURL)
        }
        
        let opfURL = extractionURL.appendingPathComponent(opfRelativePath)
        let opfFolderURL = opfURL.deletingLastPathComponent()
        
        // 4. Extract Spine Order & Metadata from OPF
        parseOPF(at: opfURL)
        
        // 5. Build parsed internal chapters sequentially
        var sequentialChapters: [Chapter] = []
        let htmlFiles = fileManager.subpaths(atPath: opfFolderURL.path)?.filter { 
            $0.hasSuffix(".html") || $0.hasSuffix(".xhtml") 
        }.sorted() ?? []
        
        for (index, file) in htmlFiles.enumerated() {
            let fullHTMLURL = opfFolderURL.appendingPathComponent(file)
            if let rawContent = try? String(contentsOf: fullHTMLURL, encoding: .utf8) {
                let paragraphs = cleanHTMLToParagraphs(rawContent)
                if !paragraphs.isEmpty {
                    let chapterTitle = "Section \(index + 1)"
                    sequentialChapters.append(Chapter(id: index, title: chapterTitle, paragraphs: paragraphs))
                }
            }
        }
        
        // Clean temporary workspace cache
        try? fileManager.removeItem(at: extractionURL)
        
        let finalTitle = temporaryTitle.isEmpty ? fileURL.deletingPathExtension().lastPathComponent.replacingOccurrences(of: "_", with: " ") : temporaryTitle
        let finalAuthor = temporaryAuthor.isEmpty ? "Local Author" : temporaryAuthor
        
        return Book(id: fileURL.lastPathComponent, title: finalTitle, author: finalAuthor, chapters: sequentialChapters)
    }
    
    // MARK: - Internal Low-Level Native Parsers
    
    private func parseContainerForOPF(at url: URL) -> String? {
        guard let data = try? Data(contentsOf: url) else { return nil }
        let parser = XMLParser(data: data)
        let containerParser = ContainerXMLParser()
        parser.delegate = containerParser
        return parser.parse() ? containerParser.opfPath : nil
    }
    
    private func parseOPF(at url: URL) {
        guard let data = try? Data(contentsOf: url) else { return }
        let parser = XMLParser(data: data)
        parser.delegate = self
        spineItemRefs.removeAll()
        temporaryTitle = ""
        temporaryAuthor = ""
        parser.parse()
    }
    
    // XML Parsing Callbacks
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        currentElement = elementName
        if elementName == "itemref", let idref = attributeDict["idref"] {
            spineItemRefs.append(idref)
        }
    }
    
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        let cleanString = string.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanString.isEmpty else { return }
        if currentElement == "dc:title" || currentElement == "title" {
            temporaryTitle += cleanString
        } else if currentElement == "dc:creator" || currentElement == "creator" {
            temporaryAuthor += cleanString
        }
    }
    
    private func cleanHTMLToParagraphs(_ html: String) -> [String] {
        var paragraphs: [String] = []
        // Simple, highly effective native regex parsing to strip structural tags cleanly
        let pattern = "<p.*?>(.*?)</p>"
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive, .dotMatchesLineSeparators]) else { return [] }
        
        let nsString = html as NSString
        let matches = regex.matches(in: html, options: [], range: NSRange(location: 0, length: nsString.length))
        
        for match in matches {
            if match.numberOfRanges > 1 {
                var pText = nsString.substring(with: match.range(at: 1))
                // Strip any embedded inline style/font tags
                pText = pText.replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression)
                let cleanText = pText.trimmingCharacters(in: .whitespacesAndNewlines)
                if !cleanText.isEmpty {
                    paragraphs.append(cleanText)
                }
            }
        }
        return paragraphs
    }
    
    private func fallbackMockBook(from url: URL) -> Book {
        let rawName = url.deletingPathExtension().lastPathComponent.replacingOccurrences(of: "_", with: " ")
        return Book(
            id: url.lastPathComponent,
            title: rawName,
            author: "Local System",
            chapters: [
                Chapter(id: 0, title: "Full Document Content", paragraphs: ["This book file was imported into your system database folder natively. Connect your audio loop playback controls to start reading through your text sequences sequentially."])
            ]
        )
    }
}

// MARK: - Secondary Helper Class for Initial Container Interrogation
private class ContainerXMLParser: NSObject, XMLParserDelegate {
    var opfPath: String?
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        if elementName == "rootfile" {
            if let path = attributeDict["full-path"] {
                opfPath = path
            }
        }
    }
}