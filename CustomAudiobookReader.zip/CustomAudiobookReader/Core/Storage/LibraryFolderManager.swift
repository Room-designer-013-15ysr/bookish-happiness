import Foundation

class LibraryFolderManager {
    static let shared = LibraryFolderManager()
    
    private init() {}
    
    /// Returns the local URL where the app's documents are stored.
    var localLibraryURL: URL? {
        return FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
    }
    
    /// Scans the local app directory for any sideloaded .epub files.
    func fetchSideloadedEPUBs() -> [URL] {
        guard let url = localLibraryURL else { return [] }
        do {
            let fileURLs = try FileManager.default.contentsOfDirectory(at: url, includingPropertiesForKeys: nil)
            return fileURLs.filter { $0.pathExtension.lowercased() == "epub" }
        } catch {
            print("Error scanning library folder: \(error.localizedDescription)")
            return []
        }
    }
}